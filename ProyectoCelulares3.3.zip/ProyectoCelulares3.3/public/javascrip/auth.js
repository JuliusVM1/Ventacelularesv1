document.addEventListener("DOMContentLoaded", function () {
    let usuarioId = sessionStorage.getItem("usuarioId");

    if (!usuarioId) {
        window.location.href = "menu.html"; 
    }
});
