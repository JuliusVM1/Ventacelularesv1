document.getElementById("registroForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const email = document.getElementById("email").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const password = document.getElementById("password").value.trim();
    const mensaje = document.getElementById("mensaje");

    const letrasRegex = /^[A-Za-zÁáÉéÍíÓóÚúÑñ\s]+$/;
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[cC][oO][mM]$/;
    const telefonoRegex = /^9[0-9]{8}$/;

    if (!nombre || !apellido || !email || !telefono || !password) {
        mensaje.innerHTML = "<span style='color: red;'>❌ Todos los campos son obligatorios</span>";
        return;
    }

    if (!letrasRegex.test(nombre)) {
        mensaje.innerHTML = "<span style='color: red;'>❌ El nombre solo puede contener letras y espacios</span>";
        return;
    }

    if (!letrasRegex.test(apellido)) {
        mensaje.innerHTML = "<span style='color: red;'>❌ El apellido solo puede contener letras y espacios</span>";
        return;
    }

    if (!emailRegex.test(email)) {
        mensaje.innerHTML = "<span style='color: red;'>❌ Ingresa un correo válido que termine en '.com'</span>";
        return;
    }

    if (!telefonoRegex.test(telefono)) {
        mensaje.innerHTML = "<span style='color: red;'>❌ El teléfono debe empezar con '9' y tener 9 dígitos</span>";
        return;
    }

    try {
        const response = await fetch("http://localhost:3000/registro", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, apellido, email, telefono, password })
        });

        const data = await response.json();
        
        if (data.message) {
            mensaje.innerHTML = `<span style='color: green;'>✅ ${data.message}. Redirigiendo a login...</span>`;
            
            document.getElementById("registroForm").reset();
            actualizarMedidor(""); 

            setTimeout(() => {
                window.location.href = "login.html";
            }, 2000);
        } else {
            mensaje.innerHTML = `<span style='color: red;'>❌ ${data.error}</span>`;
        }

    } catch (error) {
        console.error("Error en la solicitud:", error);
        mensaje.innerHTML = "<span style='color: red;'>❌ Error al conectar con el servidor</span>";
    }
});

document.getElementById("telefono").addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, '');
    if (!this.value.startsWith("9")) {
        this.value = "9";
    }
    this.value = this.value.slice(0, 9);
});

const passwordInput = document.getElementById("password");
const strengthBar = document.getElementById("passwordStrength");
const strengthText = document.getElementById("passwordStrengthText");

passwordInput.addEventListener("input", function () {
    actualizarMedidor(passwordInput.value);
});

function actualizarMedidor(password) {
    let score = 0;

    if (password.length >= 8) score++;
    if (password.match(/[A-Z]/)) score++;
    if (password.match(/[a-z]/)) score++;
    if (password.match(/[0-9]/)) score++;
    if (password.match(/[\W_]/)) score++;

    const strengthLevels = ["Muy débil", "Débil", "Regular", "Fuerte", "Muy fuerte"];
    const colors = ["red", "orange", "yellow", "blue", "green"];

    strengthBar.value = score;
    strengthBar.style.background = colors[score];
    strengthText.textContent = strengthLevels[score];
    strengthText.style.color = colors[score];
}