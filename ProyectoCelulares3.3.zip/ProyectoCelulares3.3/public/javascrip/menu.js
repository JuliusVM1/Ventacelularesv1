document.addEventListener("DOMContentLoaded", function () {
    let menuCelulares = document.getElementById("menu-celulares");
    let menuLaptops = document.getElementById("menu-laptops");
    let menuTablets = document.getElementById("menu-tablets");
    let menuNosotros = document.getElementById("menu-nosotros");
    let menuFaq = document.getElementById("menu-faq");
    let menuContacto = document.getElementById("menu-contacto");
    let iconoUsuario = document.getElementById("menu-usuario");
    let menuInicio = document.getElementById("menu-inicio");
    if (menuCelulares) menuCelulares.addEventListener("click", function () { mostrarProductos("celulares"); });
    if (menuLaptops) menuLaptops.addEventListener("click", function () { mostrarProductos("laptops"); });
    if (menuTablets) menuTablets.addEventListener("click", function () { mostrarProductos("tablets"); });

    if (menuNosotros) menuNosotros.addEventListener("click", function () {
        ocultarFiltro();
        mostrarNosotros();
    });
    if (menuFaq) menuFaq.addEventListener("click", function () {
        ocultarFiltro();
        mostrarPreguntasFrecuentes();
    });
    if (menuContacto) menuContacto.addEventListener("click", function () {
        ocultarFiltro();
        mostrarContacto();
    });
    if (iconoUsuario) iconoUsuario.addEventListener("click", mostrarOpcionesUsuario);

    if (menuInicio) {
        menuInicio.addEventListener("click", function () {
            volverPantallaInicial();
            location.reload();
        });
    }

    actualizarCarrito();
    actualizarEstadoSesion();
});

let tipoCambio = 3.80;

const productos = {
    celulares: [
        { nombre: "iPhone 13", precio: 799, imagen: "imagenes/iphone-13.jpg", marca: "Apple", anio: "2021" },
        { nombre: "iPhone 14", precio: 899, imagen: "imagenes/iphone-14.jpg", marca: "Apple", anio: "2022" },
        { nombre: "iPhone 15 Pro", precio: 1199, imagen: "imagenes/iphone-15-pro.jpg", marca: "Apple", anio: "2023" },
        { nombre: "iPhone 16", precio: 1199, imagen: "imagenes/iphone-16.jpg", marca: "Apple", anio: "2024" },

        { nombre: "Samsung Galaxy S23", precio: 999, imagen: "imagenes/samsung-s23.jpg", marca: "Samsung", anio: "2023" },
        { nombre: "Samsung Galaxy S23 Ultra", precio: 1199, imagen: "imagenes/samsung-s23-ultraj.jpg", marca: "Samsung", anio: "2023" },
        { nombre: "Samsung Galaxy A54", precio: 599, imagen: "imagenes/samsung-a54.jpg", marca: "Samsung", anio: "2022" },
        { nombre: "Samsung Galaxy Z Flip 5", precio: 1299, imagen: "imagenes/samsung-zflip5.jpg", marca: "Samsung", anio: "2024" },

        { nombre: "Xiaomi 14 Pro", precio: 899, imagen: "imagenes/xiaomi-14pro.jpg", marca: "Xiaomi", anio: "2024" },
        { nombre: "Xiaomi Redmi Note 12", precio: 499, imagen: "imagenes/xiaomi-redmi-note12.jpg", marca: "Xiaomi", anio: "2023" },
        { nombre: "Xiaomi Poco X5", precio: 349, imagen: "imagenes/xiaomi-poco-x5.jpg", marca: "Xiaomi", anio: "2022" },

        { nombre: "iPhone 12", precio: 749, imagen: "imagenes/iphone-12.jpg", marca: "Apple", anio: "2020" },
        { nombre: "iPhone 13 Mini", precio: 699, imagen: "imagenes/iphone-13mini.jpg", marca: "Apple", anio: "2021" },
        { nombre: "iPhone 14 Pro Max", precio: 1299, imagen: "imagenes/iphone-14-pro-max.jpg", marca: "Apple", anio: "2022" },

        { nombre: "Samsung Galaxy S22", precio: 899, imagen: "imagenes/samsung-s22.jpg", marca: "Samsung", anio: "2022" },
        { nombre: "Samsung Galaxy A72", precio: 649, imagen: "imagenes/samsung-a72.jpg", marca: "Samsung", anio: "2021" },
        { nombre: "Samsung Galaxy Note 20 Ultra", precio: 1099, imagen: "imagenes/samsung-note20-ultra.jpg", marca: "Samsung", anio: "2020" },

        { nombre: "Xiaomi Mi 11", precio: 799, imagen: "imagenes/xiaomi-mi11.jpg", marca: "Xiaomi", anio: "2021" },
        { nombre: "Xiaomi Redmi Note 11 Pro", precio: 599, imagen: "imagenes/xiaomi-redmi-note11pro.jpg", marca: "Xiaomi", anio: "2022" },
        { nombre: "Xiaomi Poco F3", precio: 499, imagen: "imagenes/xiaomi-poco-f3.jpg", marca: "Xiaomi", anio: "2021" }
    ],
    laptops: [
        { nombre: "MacBook Pro M2", precio: 1499, imagen: "imagenes/macbook-pro-m2.jpg", marca: "Apple", anio: "2022" },
        { nombre: "MacBook Pro M4", precio: 1599, imagen: "imagenes/MacBookProM4.jpg", marca: "Apple", anio: "2024" },
        { nombre: "MacBook Air M2", precio: 1099, imagen: "imagenes/macbook-air-m2.jpg", marca: "Apple", anio: "2022" },

        { nombre: "Dell XPS 15", precio: 1599, imagen: "imagenes/dell-xps15.jpg", marca: "Dell", anio: "2023" },
        { nombre: "Dell Inspiron 14", precio: 899, imagen: "imagenes/dell-inspiron14.jpg", marca: "Dell", anio: "2022" },
        { nombre: "Dell Latitude 15", precio: 999, imagen: "imagenes/dell-Latitude-15.jpg", marca: "Dell", anio: "2024" },

        { nombre: "Lenovo ThinkPad X1", precio: 1299, imagen: "imagenes/lenovo-thinkpad-x1.jpg", marca: "Lenovo", anio: "2023" },
        { nombre: "Lenovo IdeaPad 5", precio: 799, imagen: "imagenes/lenovo-ideapad5.jpg", marca: "Lenovo", anio: "2022" },

        { nombre: "HP Spectre x360", precio: 1399, imagen: "imagenes/hp-spectre-x360.jpg", marca: "HP", anio: "2024" },
        { nombre: "HP Spectre", precio: 1399, imagen: "imagenes/hp-spectre.jpg", marca: "HP", anio: "2023" },
        { nombre: "HP Pavilion 15", precio: 749, imagen: "imagenes/hp-pavilion15.jpg", marca: "HP", anio: "2022" },

        { nombre: "MacBook Pro M1", precio: 1399, imagen: "imagenes/macbook-pro-m1.jpg", marca: "Apple", anio: "2020" },
        { nombre: "Dell XPS 13", precio: 1399, imagen: "imagenes/dell-xps13.jpg", marca: "Dell", anio: "2022" },
        { nombre: "Lenovo Yoga 7i", precio: 1299, imagen: "imagenes/lenovo-yoga-7i.jpg", marca: "Lenovo", anio: "2023" }
    ],
    tablets: [
        { nombre: "iPad Pro 12.9", precio: 1099, imagen: "imagenes/ipad-pro-12.9.jpg", marca: "Apple", anio: "2023" },
        { nombre: "iPad Pro", precio: 1099, imagen: "imagenes/ipad-pro.jpg", marca: "Apple", anio: "2022" },
        { nombre: "iPad Air Mini 5", precio: 899, imagen: "imagenes/ipad-air-mini-5.jpg", marca: "Apple", anio: "2023" },

        { nombre: "Samsung Galaxy Tab S9", precio: 899, imagen: "imagenes/samsung-tab-s9.jpg", marca: "Samsung", anio: "2024" },
        { nombre: "Samsung Galaxy Tab A8", precio: 349, imagen: "imagenes/samsung-tab-a8.jpg", marca: "Samsung", anio: "2022" },

        { nombre: "Xiaomi Pad 6", precio: 499, imagen: "imagenes/xiaomi-pad6.jpg", marca: "Xiaomi", anio: "2023" },

        { nombre: "Lenovo Tab P12 Pro", precio: 699, imagen: "imagenes/lenovo-tab-p12.jpg", marca: "Lenovo", anio: "2024" },
        { nombre: "Lenovo Tab M11", precio: 599, imagen: "imagenes/lenovo-tab-M11.jpg", marca: "Lenovo", anio: "2023" },

        { nombre: "Huawei MatePad 11", precio: 599, imagen: "imagenes/huawei-matepad11.jpg", marca: "Huawei", anio: "2022" },

        { nombre: "iPad Mini", precio: 699, imagen: "imagenes/ipad-mini.jpg", marca: "Apple", anio: "2021" },
        { nombre: "Samsung Galaxy Tab S8", precio: 799, imagen: "imagenes/samsung-tab-s8.jpg", marca: "Samsung", anio: "2023" },
        { nombre: "Xiaomi Pad 5", precio: 549, imagen: "imagenes/xiaomi-pad5.jpg", marca: "Xiaomi", anio: "2022" }
    ]
};


function volverPantallaInicial() {
    let contenedor = document.getElementById("contenedor-productos");
    let filtroContainer = document.getElementById("filtro-container");

    if (contenedor) {
        contenedor.innerHTML = "";
    }

    if (filtroContainer) {
        filtroContainer.style.display = "none";
    }
}

document.getElementById('menu-inicio').addEventListener('click', function() {
    document.getElementById('inicio-contenido').style.display = 'block';
    
    document.getElementById("contenedor-secciones").style.display = "block";
});

document.getElementById('menu-nosotros').addEventListener('click', function() {
    document.getElementById('inicio-contenido').style.display = 'none';
    document.getElementById("contenedor-secciones").style.display = "none";
});

document.getElementById('menu-faq').addEventListener('click', function() {
    document.getElementById('inicio-contenido').style.display = 'none';
    document.getElementById("contenedor-secciones").style.display = "none";
});

document.getElementById('menu-contacto').addEventListener('click', function() {
    document.getElementById('inicio-contenido').style.display = 'none';
    document.getElementById("contenedor-secciones").style.display = "none";
});

function ocultarFiltro() {
    let filtroContainer = document.getElementById("filtro-container");
    if (filtroContainer) {
        filtroContainer.style.display = "none";
    }
}
document.getElementById("menu-celulares").addEventListener("click", function() {
    document.getElementById("contenedor-secciones").style.display = "none"; 
});

document.getElementById("menu-laptops").addEventListener("click", function() {
    document.getElementById("contenedor-secciones").style.display = "none"; 
});

document.getElementById("menu-tablets").addEventListener("click", function() {
    document.getElementById("contenedor-secciones").style.display = "none";
});


function mostrarProductos(categoria) {
    let contenedor = document.getElementById("contenedor-productos");
    if (!contenedor) return;

    let filtroContainer = document.getElementById("filtro-container");
    if (filtroContainer) {
        filtroContainer.style.display = "block";
    }

    contenedor.innerHTML = `<h2 class="text-center">${categoria.charAt(0).toUpperCase() + categoria.slice(1)}</h2>`;

    let productosPorMarca = agruparPorMarca(productos[categoria]);

    for (let marca in productosPorMarca) {
        contenedor.innerHTML += `
            <h3 class="text-center mt-4">${marca}</h3>
            <div class="productos-grid">
                ${crearItemsProductos(productosPorMarca[marca])}
            </div>
        `;
    }
}

function crearItemsProductos(productos) {
    return productos.map(producto => `
        <div class="card">
            <img src="${producto.imagen}" alt="${producto.nombre}">
            <p>${producto.nombre}</p>
            <p class="precio">S/ ${(producto.precio * tipoCambio).toFixed(2)}</p>
            <button onclick='agregarAlCarrito(${JSON.stringify(producto)})'>Añadir</button>
        </div>
    `).join('');
}

function moveCarousel(idCarrusel, direction) {
    const carousel = document.getElementById(idCarrusel);
    if (!carousel) return;
    const scrollAmount = 270; 
    carousel.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
}

function agruparPorMarca(listaProductos) {
    return listaProductos.reduce((grupo, producto) => {
        if (!grupo[producto.marca]) grupo[producto.marca] = [];
        grupo[producto.marca].push(producto);
        return grupo;
    }, {});
}

function crearItemsCarrusel(productos) {
    return productos.map(producto => `
        <div class="card">
            <img src="${producto.imagen}" alt="${producto.nombre}">
            <p>${producto.nombre}</p>
            <p class="precio">S/ ${(producto.precio * tipoCambio).toFixed(2)}</p>
            <button onclick='agregarAlCarrito(${JSON.stringify(producto)})'>Añadir</button>
        </div>
    `).join('');
}

document.getElementById("inicio").addEventListener("click", function() {
    window.location.href = "menu.html";
});


function actualizarCarrito() {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    document.getElementById("contador-carrito").innerText = carrito.length;
}

function mostrarOpcionesUsuario() {
    let iconoUsuario = document.getElementById("menu-usuario");

    let opcionesUsuarioExistente = document.getElementById("usuario-menu");
    if (opcionesUsuarioExistente) {
        opcionesUsuarioExistente.remove();
        return;
    }

    let opcionesUsuario = document.createElement("div");
    opcionesUsuario.id = "usuario-menu";
    opcionesUsuario.classList.add("usuario-menu");

    let usuarioId = sessionStorage.getItem("usuarioId");
    if (usuarioId) {
        opcionesUsuario.innerHTML = `
            <button onclick="verCuenta()">Mi cuenta</button>
            <button onclick="cerrarSesion()">Cerrar sesión</button>
        `;
    } else {
        opcionesUsuario.innerHTML = `
            <button onclick="verCuenta()">Iniciar sesión</button>
        `;
    }

    iconoUsuario.parentNode.appendChild(opcionesUsuario);
}

function actualizarEstadoSesion() {
    let iconoUsuario = document.getElementById("menu-usuario");
    if (!iconoUsuario) return;

    let usuarioId = sessionStorage.getItem("usuarioId");
    if (usuarioId) {
        iconoUsuario.innerHTML = "Mi cuenta";
    } else {
        iconoUsuario.innerHTML = "Iniciar sesión";
    }
}

async function verCuenta() {
    let usuarioId = sessionStorage.getItem("usuarioId");

    if (!usuarioId) {
        window.location.href = "login.html";
        return;
    }

    try {
        let response = await fetch(`http://localhost:3000/usuario/${usuarioId}`);

        if (!response.ok) {
            throw new Error("Error al obtener los datos del usuario");
        }

        let usuario = await response.json();

        let contenedor = document.getElementById("contenedor-productos");
        if (!contenedor) {
            console.error("No se encontró el contenedor para mostrar la cuenta.");
            return;
        }

        contenedor.innerHTML = `
            <h2 class="text-center">Mi Cuenta</h2>
            <p class="text-center"><b>👤 Nombres:</b> ${usuario.nombre}</p>
            <p class="text-center"><b>📛 Apellidos:</b> ${usuario.apellido}</p>
            <p class="text-center"><b>📧 Correo:</b> ${usuario.email}</p>
            <p class="text-center"><b>📞 Teléfono:</b> ${usuario.telefono}</p>
            <button class="btn btn-danger mt-3" onclick="cerrarSesion()">Cerrar Sesión</button>
        `;
    } catch (error) {
        console.error("Error al cargar los datos del usuario:", error);
    }
}

function cerrarSesion() {
    sessionStorage.clear();
    localStorage.removeItem("carrito");
    window.location.href = "menu.html";
    window.history.replaceState(null, null, "menu.html");
}

document.getElementById("btnFiltro").addEventListener("click", function() {
    let panel = document.getElementById("filtroPanel");
    panel.style.right = panel.style.right === "0px" ? "-300px" : "0px";
});

function obtenerCarrito() {
    return JSON.parse(localStorage.getItem("carrito")) || [];
}

function guardarCarrito(carrito) {
    localStorage.setItem("carrito", JSON.stringify(carrito));
}

function agregarAlCarrito(producto) {
    let usuarioId = sessionStorage.getItem("usuarioId");
    if (!usuarioId) {
        alert("Debes iniciar sesión para agregar productos al carrito.");
        window.location.href = "login.html";
        return;
    }

    let carrito = obtenerCarrito();
    carrito.push(producto);
    guardarCarrito(carrito);
    alert(`${producto.nombre} ha sido añadido al carrito.`);
    actualizarCarrito();
}

function aplicarFiltro() {
    let categoria = document.getElementById('contenedor-productos').getAttribute('data-categoria');
    let marca = document.getElementById('filtro-marca').value;
    let anio = document.getElementById('filtro-anio').value;

    let productosFiltrados = productos[categoria].filter(p =>
        (marca === "" || p.marca === marca) &&
        (anio === "" || p.anio.toString() === anio)
    );

    mostrarProductosFiltrados(productosFiltrados);
}

function mostrarProductosFiltrados(productosFiltrados) {
    let contenedor = document.getElementById('contenedor-productos');
    if (productosFiltrados.length > 0) {
        let html = "<h2>Resultados de búsqueda</h2><div class='row'>";
        productosFiltrados.forEach(producto => {
            html += `
                <div class="col-md-4">
                    <div class="card mb-3">
                        <img src="${producto.imagen}" class="card-img-top" alt="${producto.nombre}">
                        <div class="card-body">
                            <h5 class="card-title">${producto.nombre}</h5>
                            <p class="card-text"><strong>Marca:</strong> ${producto.marca}</p>
                            <p class="card-text"><strong>Año:</strong> ${producto.anio}</p>
                            <button class="btn btn-primary" onclick="agregarAlCarrito(${JSON.stringify(producto)})">
                                Añadir al carrito
                            </button>
                        </div>
                    </div>
                </div>`;
        });
        html += "</div>";
        contenedor.innerHTML = html;
    } else {
        contenedor.innerHTML = "<p>No se encontraron productos.</p>";
    }
}

function actualizarMarcas(categoria) {
    let selectMarca = document.getElementById('filtro-marca');
    selectMarca.innerHTML = '<option value="">Todas</option>';

    let marcasDisponibles = new Set();
    if (productos[categoria]) {
        productos[categoria].forEach(producto => {
            marcasDisponibles.add(producto.marca);
        });
    }

    marcasDisponibles.forEach(marca => {
        let option = document.createElement('option');
        option.value = marca;
        option.textContent = marca;
        selectMarca.appendChild(option);
    });
}

function mostrarCategoria(categoria) {
    document.getElementById('contenedor-productos').setAttribute('data-categoria', categoria);
    document.getElementById('filtro-container').style.display = 'block';
    mostrarProductos(categoria);
    actualizarMarcas(categoria);
}
