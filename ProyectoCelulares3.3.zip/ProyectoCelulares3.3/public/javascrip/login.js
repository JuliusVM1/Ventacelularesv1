document.getElementById("loginForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const mensaje = document.getElementById("mensaje");

    if (!email || !password) {
        mensaje.innerHTML = "<span style='color: red;'>❌ Todos los campos son obligatorios</span>";
        return;
    }

    try {
        const response = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (data.success) {
            sessionStorage.setItem("usuarioId", data.user.id);
            sessionStorage.setItem("usuarioEmail", data.user.email);

            mensaje.innerHTML = "<span style='color: green;'>✅ Inicio de sesión exitoso</span>";
            setTimeout(() => { window.location.href = "menu.html"; }, 2000);
        } else {
            mensaje.innerHTML = `<span style='color: red;'>❌ ${data.message}</span>`;
        }
    } catch (error) {
        console.error("Error:", error);
        mensaje.innerHTML = "<span style='color: red;'>❌ Error en el servidor</span>";
    }
});