function mostrarPreguntasFrecuentes() {
    let contenedor = document.getElementById("contenedor-productos");
    if (!contenedor) return;

    contenedor.innerHTML = `
        <h2 class="text-center">❓ Preguntas Frecuentes (FAQ) 📌</h2>

        <h3 class="mt-4">📲 Servicios y Planes</h3>
        <p><strong>🔹 ¿Cuáles son los planes de Movistar disponibles?</strong></p>
        <p>Movistar ofrece planes de telefonía móvil, Internet y televisión. Puedes revisar las opciones en su página web oficial o en tiendas autorizadas.</p>
        
        <p><strong>🔹 ¿Cómo cambiar mi plan de Movistar?</strong></p>
        <p>Puedes cambiar tu plan llamando al servicio al cliente al *611 o desde la app Mi Movistar.</p>

        <p><strong>🔹 ¿Movistar tiene planes sin contrato?</strong></p>
        <p>Sí, Movistar ofrece planes prepago y postpago sin contrato. Consulta en una tienda para más información.</p>

        <h3 class="mt-4">💳 Facturación y Pagos</h3>
        <p><strong>🔹 ¿Cómo pagar mi recibo de Movistar?</strong></p>
        <p>Puedes pagar tu recibo a través de la app Mi Movistar, banca por Internet, agentes autorizados o en las oficinas de Movistar.</p>

        <p><strong>🔹 ¿Cómo consultar mi saldo?</strong></p>
        <p>Marca *611# y selecciona la opción de saldo o revisa en la app Mi Movistar.</p>

        <p><strong>🔹 ¿Qué pasa si me atraso en mi pago?</strong></p>
        <p>Si te atrasas en el pago, podrías recibir una suspensión temporal del servicio hasta regularizar tu deuda.</p>

        <h3 class="mt-4">📶 Internet y Cobertura</h3>
        <p><strong>🔹 ¿Cómo saber si tengo cobertura de fibra óptica?</strong></p>
        <p>Puedes verificar la cobertura en la página de Movistar ingresando tu dirección en la sección de consulta de cobertura.</p>

        <p><strong>🔹 ¿Por qué mi Internet está lento?</strong></p>
        <p>Puede deberse a congestión de la red, problemas con tu router o dispositivos conectados. Te recomendamos reiniciar tu módem y verificar la velocidad en la app Mi Movistar.</p>

        <p><strong>🔹 ¿Movistar ofrece Internet en zonas rurales?</strong></p>
        <p>Sí, Movistar tiene el programa "Internet Para Todos" que busca llevar conectividad a zonas alejadas del país.</p>

        <h3 class="mt-4">📞 Atención al Cliente</h3>
        <p><strong>🔹 ¿Cómo contactar con el servicio al cliente?</strong></p>
        <p>Puedes comunicarte al *611 desde tu celular Movistar o usar el chat en línea en la web oficial.</p>

        <p><strong>🔹 ¿Dónde encuentro una tienda Movistar?</strong></p>
        <p>Puedes ubicar la tienda más cercana en la web de Movistar ingresando tu ubicación.</p>

        <p><strong>🔹 ¿Cómo reportar una línea robada o perdida?</strong></p>
        <p>Llama inmediatamente al *611 o acude a una tienda Movistar para bloquear la línea y evitar su uso no autorizado.</p>

        <h3 class="mt-4">📡 TV y Streaming</h3>
        <p><strong>🔹 ¿Qué es Movistar Play?</strong></p>
        <p>Movistar Play es el servicio de streaming de Movistar que te permite ver canales en vivo y contenido bajo demanda.</p>

        <p><strong>🔹 ¿Cómo activar Movistar Play?</strong></p>
        <p>Descarga la app Movistar Play, regístrate con tu número Movistar y accede a los contenidos disponibles según tu plan.</p>

        <h3 class="mt-4">🔐 Seguridad y Privacidad</h3>
        <p><strong>🔹 ¿Cómo proteger mi cuenta de Movistar?</strong></p>
        <p>Usa contraseñas seguras, activa la verificación en dos pasos y nunca compartas tu información personal con desconocidos.</p>

        <p><strong>🔹 ¿Movistar vende mis datos personales?</strong></p>
        <p>No, Movistar cumple con las regulaciones de protección de datos y no comercializa la información de sus usuarios.</p>

        <h3 class="mt-4">📦 Otros Servicios</h3>
        <p><strong>🔹 ¿Movistar tiene descuentos para empresas?</strong></p>
        <p>Sí, hay planes y beneficios especiales para empresas. Puedes consultar en la web o en oficinas de Movistar Empresas.</p>

        <p><strong>🔹 ¿Cómo solicitar una portabilidad a Movistar?</strong></p>
        <p>Si quieres cambiarte a Movistar sin perder tu número, visita una tienda con tu DNI y solicita la portabilidad.</p>

        <h3 class="mt-4">🛠 Soporte Técnico</h3>
        <p><strong>🔹 ¿Qué hacer si mi línea no funciona?</strong></p>
        <p>Verifica si tienes saldo (si eres prepago) o si hay interrupciones de servicio en tu zona. Si el problema persiste, contacta con el soporte de Movistar.</p>

        <p><strong>🔹 ¿Cómo reiniciar mi router?</strong></p>
        <p>Desconéctalo de la corriente por 10 segundos y vuelve a encenderlo. Espera unos minutos hasta que se restablezca la conexión.</p>

        <p><strong>🔹 ¿Qué hacer si mi celular no tiene señal?</strong></p>
        <p>Intenta activar y desactivar el modo avión, reinicia tu celular o revisa si hay problemas de red en tu área.</p>
    `;
}
