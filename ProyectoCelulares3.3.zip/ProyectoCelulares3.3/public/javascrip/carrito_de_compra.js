document.addEventListener("DOMContentLoaded", function () {
    mostrarCarrito();
});

function mostrarCarrito() {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    let contenedor = document.getElementById("productos-seleccionados");

    if (carrito.length === 0) {
        contenedor.innerHTML = "<p>No hay productos en el carrito.</p>";
        return;
    }

    contenedor.innerHTML = "";

    carrito.forEach((producto, index) => {
        let divProducto = document.createElement("div");
        divProducto.classList.add("producto-carrito");
        divProducto.innerHTML = `
            <img src="${producto.imagen}" width="50">
            <p>${producto.nombre} - S/ ${(producto.precio * 3.80).toFixed(2)}</p>
            <button onclick="eliminarDelCarrito(${index})">❌</button>
        `;
        contenedor.appendChild(divProducto);
    });

    calcularTotal();
}

function calcularTotal() {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    let total = carrito.reduce((sum, producto) => sum + (producto.precio * 3.80), 0);
    document.getElementById("total").innerText = `Total: S/ ${total.toFixed(2)}`;
}

function eliminarDelCarrito(index) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    carrito.splice(index, 1);
    localStorage.setItem("carrito", JSON.stringify(carrito));
    mostrarCarrito();
}

function vaciarCarrito() {
    localStorage.removeItem("carrito");
    mostrarCarrito();
}
