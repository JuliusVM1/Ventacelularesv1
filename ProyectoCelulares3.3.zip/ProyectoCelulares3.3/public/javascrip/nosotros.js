function mostrarNosotros() {
    let contenedor = document.getElementById("contenedor-productos");
    if (!contenedor) return;

    contenedor.innerHTML = `
        <h2 class="text-center">Sobre Movistar Perú</h2>

        <h3 class="mt-4">📅 Historia y Fundación</h3>
        <p>
            Movistar es una marca de telecomunicaciones operada por Telefónica, una de las compañías más grandes del mundo en este sector. 
            Telefónica inició operaciones en Perú en 1994 y, desde entonces, ha liderado la evolución de las telecomunicaciones en el país. 
            A lo largo de los años, ha sido pionera en la expansión de servicios móviles, Internet y televisión digital, conectando a millones de peruanos.
        </p>

        <h3 class="mt-4">📡 Servicios de Movistar en Perú</h3>
        <p>
            Movistar ofrece una amplia gama de servicios en el país, incluyendo:
        </p>
        <ul>
            <li>📞 Telefonía móvil y fija</li>
            <li>🌐 Internet de alta velocidad (fibra óptica y 4G/5G)</li>
            <li>📺 Televisión digital y Movistar Play</li>
            <li>🏢 Soluciones empresariales en telecomunicaciones</li>
            <li>🛜 Internet satelital para zonas rurales</li>
        </ul>

        <h3 class="mt-4">🚀 Innovación y Proyectos a Futuro</h3>
        <p>
            Movistar Perú está comprometido con la transformación digital del país. Algunos de sus proyectos más importantes incluyen:
        </p>
        <ul>
            <li><strong>📶 Expansión del 5G:</strong> Movistar está desplegando tecnología 5G en todo el país para ofrecer mayor velocidad y estabilidad en la conexión.</li>
            <li><strong>📡 Internet en zonas rurales:</strong> A través de su programa "Internet Para Todos", Movistar busca conectar a comunidades alejadas con Internet de calidad.</li>
            <li><strong>🧠 Inteligencia Artificial:</strong> Desarrollo de asistentes virtuales y chatbots para mejorar la experiencia del usuario.</li>
            <li><strong>♻ Sostenibilidad:</strong> Programas de reciclaje de celulares y reducción del impacto ambiental en sus operaciones.</li>
            <li><strong>📱 Innovaciones en TV:</strong> Mejoras en Movistar Play y nuevas integraciones con servicios de streaming.</li>
        </ul>

        <h3 class="mt-4">🌍 Responsabilidad Social y Compromiso Ambiental</h3>
        <p>
            Movistar Perú no solo busca liderar en telecomunicaciones, sino también generar un impacto positivo en la sociedad y el medio ambiente. Algunos de sus programas incluyen:
        </p>
        <ul>
            <li><strong>📚 Educación Digital:</strong> Programas de formación en tecnología para estudiantes y emprendedores.</li>
            <li><strong>🌱 Movistar Verde:</strong> Iniciativa de reciclaje de celulares y reducción de residuos electrónicos.</li>
            <li><strong>🩺 Salud Conectada:</strong> Telemedicina y conectividad para hospitales en zonas alejadas.</li>
            <li><strong>📶 Inclusión Digital:</strong> Expansión de redes para reducir la brecha digital en comunidades rurales.</li>
        </ul>

        <h3 class="mt-4">📍 Ubicaciones de Movistar en Perú</h3>
        <p>
            Movistar cuenta con múltiples oficinas y tiendas en todo el país. Aquí puedes encontrar algunas de sus principales sedes:
        </p>
        
        <ul>
            <li>📌 Lima - Av. Javier Prado Este 123</li>
            <li>📌 Arequipa - Calle Mercaderes 456</li>
            <li>📌 Trujillo - Av. España 789</li>
            <li>📌 Chiclayo - Jr. Balta 321</li>
            <li>📌 Piura - Av. Grau 567</li>
            <li>📌 Cusco - Calle Plateros 234</li>
        </ul>
    `;
}