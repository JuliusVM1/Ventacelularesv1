function mostrarContacto() {
    let contenedor = document.getElementById("contenedor-productos");
    if (!contenedor) return;

    contenedor.innerHTML = `
        <div class="container p-4">
            <h2 class="text-center mb-4">📞 ¡Contáctanos! 💬</h2>

            <p class="text-center">¿Tienes dudas, necesitas ayuda o quieres más información? ¡Estamos aquí para ti! 👇</p>

            <div class="card shadow-sm p-3 mb-4">
                <h3 class="mt-2">📲 Atención al Cliente</h3>
                <p><strong>☎️ Teléfono:</strong> 955187651</p>
                <p><strong>📩 Correo Electrónico:</strong> <a href="mailto:atencion@movistar.com.pe">atencion@movistar.com.pe</a></p>
                <p><strong>💬 WhatsApp:</strong> <a href="https://wa.me/955187651" target="_blank">Haz clic aquí para chatear</a></p>
                <p><strong>🕘 Horario de Atención:</strong> Lunes a Domingo, 8:00 AM - 10:00 PM</p>
            </div>

            <div class="card shadow-sm p-3 mb-4">
                <h3 class="mt-2">📍 Nuestras Oficinas</h3>
                <p>Encuéntranos en nuestras principales sedes en Perú:</p>
                <ul>
                    <li>📍 <strong>Lima:</strong> Av. Javier Prado Este 4010, San Isidro</li>
                    <li>📍 <strong>Arequipa:</strong> Av. Ejército 1020, Yanahuara</li>
                    <li>📍 <strong>Trujillo:</strong> Jr. Pizarro 725, Centro Histórico</li>
                    <li>📍 <strong>Chiclayo:</strong> Av. Balta 810, Cercado</li>
                    <li>📍 <strong>Piura:</strong> Av. Grau 230, Piura Centro</li>
                </ul>
            </div>

            <div class="card shadow-sm p-3 mb-4">
                <h3 class="mt-2">🔧 Soporte Técnico</h3>
                <p>Si tienes problemas con tu servicio, puedes comunicarte con nuestro equipo de soporte:</p>
                <p><strong>📞 Línea de Soporte:</strong> 955187651</p>
                <p><strong>📧 Email de Soporte:</strong> <a href="mailto:soporte@movistar.com.pe">soporte@movistar.com.pe</a></p>
                <p><strong>🛠 Chat en Vivo:</strong> Disponible en nuestra <a href="https://www.movistar.com.pe" target="_blank">página web oficial</a></p>
            </div>

            <div class="card shadow-sm p-3 mb-4">
                <h3 class="mt-2">💼 Trabaja con Nosotros</h3>
                <p>¿Quieres formar parte del equipo de Movistar? Envíanos tu CV a:</p>
                <p><strong>📧 Email de Reclutamiento:</strong> <a href="mailto:empleos@movistar.com.pe">empleos@movistar.com.pe</a></p>
            </div>

            <div class="card shadow-sm p-3">
                <h3 class="mt-2">🌍 Síguenos en Redes Sociales</h3>
                <p>¡No te pierdas nuestras novedades, promociones y noticias!</p>
                <ul>
                    <li>📘 <strong>Facebook:</strong> <a href="https://www.facebook.com/movistarperu" target="_blank">Movistar Perú</a></li>
                    <li>📷 <strong>Instagram:</strong> <a href="https://www.instagram.com/movistarperu" target="_blank">@movistarperu</a></li>
                    <li>🐦 <strong>Twitter (X):</strong> <a href="https://twitter.com/movistarperu" target="_blank">@MovistarPeru</a></li>
                    <li>🎥 <strong>YouTube:</strong> <a href="https://www.youtube.com/user/movistarperu" target="_blank">Movistar Perú</a></li>
                </ul>
            </div>
        </div>
    `;
}
