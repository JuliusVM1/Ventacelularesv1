require("dotenv").config();
const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");

const app = express();
const PORT = 3000;

app.use(cors({
    origin: "http://localhost",
    methods: ["GET", "POST"],
    credentials: true
}));
app.use(bodyParser.json());
app.use(express.static("public"));

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

db.connect((err) => {
    if (err) {
        console.error("❌ Error conectando a la base de datos:", err.message);
        process.exit(1);
    }
    console.log("✅ Conectado a MySQL");
});

app.post("/registro", async (req, res) => {
    const { nombre, apellido, email, telefono, password } = req.body;

    if (!nombre || !apellido || !email || !telefono || !password) {
        return res.status(400).json({ error: "❌ Todos los campos son obligatorios" });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const sql = "INSERT INTO usuarios (nombre, apellido, email, telefono, password) VALUES (?, ?, ?, ?, ?)";
        const values = [nombre, apellido, email.toLowerCase().trim(), telefono, hashedPassword];

        db.query(sql, values, (err, result) => {
            if (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    return res.status(400).json({ error: "❌ El correo ya está registrado" });
                }
                console.error("Error al registrar usuario:", err.message);
                return res.status(500).json({ error: "❌ Error en el servidor" });
            }
            res.json({ message: "✅ Usuario registrado con éxito", id: result.insertId });
        });
    } catch (error) {
        console.error("Error al encriptar la contraseña:", error.message);
        res.status(500).json({ error: "❌ Error en el servidor" });
    }
});

app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    console.log("📩 Datos recibidos en /login:", email, password);

    if (!email || !password) {
        return res.status(400).json({ success: false, message: "❌ Todos los campos son obligatorios" });
    }

    const sql = "SELECT * FROM usuarios WHERE email = ?";
    db.query(sql, [email.toLowerCase().trim()], async (err, results) => {
        if (err) {
            console.error("⚠️ Error en la consulta SQL:", err.message);
            return res.status(500).json({ success: false, message: "❌ Error en el servidor" });
        }

        console.log("🔍 Resultado de la consulta:", results);

        if (results.length === 0) {
            return res.status(401).json({ success: false, message: "❌ Usuario no encontrado" });
        }

        const user = results[0];
        console.log("🔑 Usuario encontrado:", user);

        const passwordMatch = await bcrypt.compare(password, user.password);
        console.log("🔄 Comparación de contraseña:", passwordMatch);

        if (!passwordMatch) {
            return res.status(401).json({ success: false, message: "❌ Contraseña incorrecta" });
        }

        res.json({ success: true, message: "✅ Inicio de sesión exitoso", user: { id: user.id, email: user.email } });
    });
});

app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});

app.get("/usuario/:id", (req, res) => {
    const usuarioId = req.params.id;

    const sql = "SELECT id, nombre, apellido, email, telefono FROM usuarios WHERE id = ?";
    db.query(sql, [usuarioId], (err, results) => {
        if (err) {
            console.error("Error en la consulta:", err);
            return res.status(500).json({ success: false, message: "❌ Error en el servidor" });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: "❌ Usuario no encontrado" });
        }

        res.json(results[0]); // Enviar el usuario encontrado
    });
});